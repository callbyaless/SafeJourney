// Importar módulos de Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, doc, getDoc, addDoc, setDoc, updateDoc, deleteDoc, onSnapshot, collection, query, where, orderBy, serverTimestamp, getDocs } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// Variables globales para Firebase (proporcionadas por el entorno Canvas)
const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-safety-app';
const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};
const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

let app;
let db;
let auth;
let userId = 'anonymous'; // Valor predeterminado hasta que se autentique
let isAuthReady = false;

/**
 * Muestra un modal personalizado con un mensaje.
 * @param {string} message - El mensaje a mostrar en el modal.
 */
function showModal(message) {
    document.getElementById('modalMessage').innerText = message;
    document.getElementById('appModal').style.display = 'flex';
}

/**
 * Cierra el modal personalizado.
 */
window.closeModal = function() {
    document.getElementById('appModal').style.display = 'none';
}

/**
 * Inicializa Firebase y configura la autenticación.
 */
async function initializeFirebase() {
    try {
        if (Object.keys(firebaseConfig).length === 0) {
            console.error("Firebase config is empty. Please ensure __firebase_config is correctly provided.");
            showModal("Error de configuración: Firebase no está configurado correctamente.");
            return;
        }
        app = initializeApp(firebaseConfig);
        db = getFirestore(app);
        auth = getAuth(app);

        // Escucha los cambios en el estado de autenticación
        onAuthStateChanged(auth, async (user) => {
            if (user) {
                userId = user.uid;
                document.getElementById('userIdDisplay').innerText = userId;
                console.log("Usuario autenticado:", userId);
            } else {
                // Inicia sesión de forma anónima si no hay token o sesión previa
                try {
                    if (initialAuthToken) {
                        await signInWithCustomToken(auth, initialAuthToken);
                        console.log("Signed in with custom token.");
                    } else {
                        await signInAnonymously(auth);
                        console.log("Signed in anonymously.");
                    }
                } catch (error) {
                    console.error("Error al iniciar sesión:", error);
                    showModal(`Error al iniciar sesión: ${error.message}`);
                }
            }
            isAuthReady = true; // El estado de autenticación ha sido verificado
            // Ahora que la autenticación está lista, configura los oyentes de Firestore
            setupFirestoreListeners();
        });

    } catch (error) {
        console.error("Error al inicializar Firebase:", error);
        showModal(`Error al inicializar Firebase: ${error.message}`);
    }
}

/**
 * Configura los oyentes de Firestore después de que la autenticación esté lista.
 */
function setupFirestoreListeners() {
    if (!isAuthReady || !db) {
        console.warn("Los oyentes de Firestore no se configuraron: la autenticación no está lista o la base de datos no está inicializada.");
        return;
    }

    // Escucha los reportes comunitarios
    const reportsColRef = collection(db, `artifacts/${appId}/public/data/communityReports`);
    const qReports = query(reportsColRef); // Se eliminó orderBy para compatibilidad
    onSnapshot(qReports, (snapshot) => {
        const reports = [];
        snapshot.forEach(doc => {
            reports.push({ id: doc.id, ...doc.data() });
        });
        // Ordenar por marca de tiempo descendente en memoria
        reports.sort((a, b) => (b.timestamp?.toDate() || 0) - (a.timestamp?.toDate() || 0));
        displayCommunityReports(reports);
    }, (error) => {
        console.error("Error al obtener los reportes comunitarios:", error);
        showModal(`Error al cargar reportes comunitarios: ${error.message}`);
    });
}

// Hacer showModal accesible globalmente
window.showModal = showModal;

// --- Lógica de Navegación ---
document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('.nav-button');
    const sections = document.querySelectorAll('.section-content');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Elimina la clase activa de todos los botones y secciones
            navButtons.forEach(btn => btn.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));

            // Agrega la clase activa al botón clicado
            button.classList.add('active');

            // Muestra la sección de destino
            const targetId = button.dataset.target;
            document.getElementById(targetId).classList.add('active');
        });
    });

    // Inicializa Firebase cuando el DOM esté listo
    initializeFirebase();
});

// --- Lógica del Botón de Pánico ---
const activatePanicButton = document.getElementById('activatePanic');
const panicStatusDiv = document.getElementById('panicStatus');
const latitudeSpan = document.getElementById('latitude');
const longitudeSpan = document.getElementById('longitude');
const accuracySpan = document.getElementById('accuracy');
const timestampSpan = document.getElementById('timestamp');
const copyLocationButton = document.getElementById('copyLocation');

activatePanicButton.addEventListener('click', () => {
    panicStatusDiv.innerHTML = '<p class="text-red-600 font-semibold">¡Alerta de pánico activada! Enviando ubicación...</p>';
    activatePanicButton.disabled = true;

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                const acc = position.coords.accuracy;
                const time = new Date(position.timestamp).toLocaleString();

                latitudeSpan.innerText = `Latitud: ${lat.toFixed(6)}`;
                longitudeSpan.innerText = `Longitud: ${lon.toFixed(6)}`;
                accuracySpan.innerText = `Precisión: ${acc.toFixed(2)} metros`;
                timestampSpan.innerText = `Hora: ${time}`;

                const locationMessage = `¡AYUDA! Mi ubicación actual es: Latitud ${lat}, Longitud ${lon}. Precisión: ${acc.toFixed(2)}m. Hora: ${time}.`;
                panicStatusDiv.innerHTML += `<p class="mt-2 text-green-600">Ubicación enviada a contactos de emergencia.</p>`;
                showModal(`Ubicación enviada:\n${locationMessage}\n\nGrabación de audio iniciada (simulado).\nLlamando al 911 (simulado).`);

                // Simula el envío a contactos de emergencia (en una aplicación real, esto sería una llamada al backend)
                console.log("Simulando envío a contactos de emergencia:", locationMessage);
                // Simula el inicio de la grabación de audio
                console.log("Simulando inicio de grabación de audio...");
                // Simula la llamada al 911
                console.log("Simulando llamada al 911...");

                activatePanicButton.disabled = false;
            },
            (error) => {
                console.error("Error al obtener la ubicación:", error);
                panicStatusDiv.innerHTML = `<p class="text-red-600">Error al obtener la ubicación: ${error.message}</p>`;
                showModal(`Error al obtener la ubicación: ${error.message}. Asegúrate de permitir el acceso a la ubicación.`);
                activatePanicButton.disabled = false;
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    } else {
        panicStatusDiv.innerHTML = '<p class="text-red-600">Geolocalización no es soportada por tu navegador.</p>';
        showModal("Tu navegador no soporta la geolocalización.");
        activatePanicButton.disabled = false;
    }
});

copyLocationButton.addEventListener('click', () => {
    const locationText = `Latitud: ${latitudeSpan.innerText.replace('Latitud: ', '')}, Longitud: ${longitudeSpan.innerText.replace('Longitud: ', '')}, Precisión: ${accuracySpan.innerText.replace('Precisión: ', '')}, Hora: ${timestampSpan.innerText.replace('Hora: ', '')}`;
    copyToClipboard(locationText, "Ubicación copiada al portapapeles.");
});

/**
 * Copia un texto al portapapeles.
 * @param {string} text - El texto a copiar.
 * @param {string} successMessage - Mensaje a mostrar si la copia es exitosa.
 */
function copyToClipboard(text, successMessage) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        showModal(successMessage);
    } catch (err) {
        console.error('Error al copiar al portapapeles:', err);
        showModal('Error al copiar al portapapeles. Inténtalo manualmente.');
    }
    document.body.removeChild(textarea);
}

// --- Lógica de Compartir Viaje en Tiempo Real ---
const startTripShareButton = document.getElementById('startTripShare');
const stopTripShareButton = document.getElementById('stopTripShare');
const copyTripDetailsButton = document.getElementById('copyTripDetails');
const destinationInput = document.getElementById('destination');
const driverNameInput = document.getElementById('driverName');
const vehicleInfoInput = document.getElementById('vehicleInfo');
const tripShareStatusDiv = document.getElementById('tripShareStatus');
const currentRouteSpan = document.getElementById('currentRoute');
const estimatedTimeSpan = document.getElementById('estimatedTime');
const driverDetailsSpan = document.getElementById('driverDetails');
const vehicleDetailsSpan = document.getElementById('vehicleDetails');

let tripInterval;

startTripShareButton.addEventListener('click', () => {
    const destination = destinationInput.value || 'Destino no especificado';
    const driverName = driverNameInput.value || 'N/A';
    const vehicleInfo = vehicleInfoInput.value || 'N/A';

    if (!destination) {
        showModal("Por favor, ingresa un destino para iniciar el viaje.");
        return;
    }

    tripShareStatusDiv.classList.remove('hidden');
    startTripShareButton.disabled = true;
    stopTripShareButton.disabled = false;

    driverDetailsSpan.innerText = `Conductor: ${driverName}`;
    vehicleDetailsSpan.innerText = `Vehículo: ${vehicleInfo}`;

    let simulatedDistance = 0;
    const totalDistance = 10; // km
    const speed = 0.5; // km/segundo para la simulación

    tripInterval = setInterval(() => {
        simulatedDistance += speed;
        if (simulatedDistance >= totalDistance) {
            simulatedDistance = totalDistance;
            clearInterval(tripInterval);
            showModal("¡Has llegado a tu destino!");
            stopTripShareButton.disabled = true;
            startTripShareButton.disabled = false;
        }

        const remainingDistance = totalDistance - simulatedDistance;
        const remainingTimeSeconds = remainingDistance / speed;
        const etaMinutes = Math.ceil(remainingTimeSeconds / 60);

        currentRouteSpan.innerText = `Ruta: ${simulatedDistance.toFixed(1)} km de ${totalDistance} km hacia ${destination}`;
        estimatedTimeSpan.innerText = `ETA: ${etaMinutes} minutos restantes`;
    }, 1000); // Actualiza cada segundo
    showModal("Compartiendo viaje en tiempo real. ¡Mantente seguro!");
});

stopTripShareButton.addEventListener('click', () => {
    clearInterval(tripInterval);
    tripShareStatusDiv.classList.add('hidden');
    startTripShareButton.disabled = false;
    stopTripShareButton.disabled = true;
    showModal("Compartir viaje detenido.");
});

copyTripDetailsButton.addEventListener('click', () => {
    const tripDetails = `Estoy en un viaje hacia ${destinationInput.value || 'un destino'}. ${currentRouteSpan.innerText}. ${estimatedTimeSpan.innerText}. Conductor: ${driverNameInput.value || 'N/A'}. Vehículo: ${vehicleInfoInput.value || 'N/A'}.`;
    copyToClipboard(tripDetails, "Detalles del viaje copiados al portapapeles.");
});

// --- Lógica de Verificación de Conductor (Firestore) ---
const plateNumberInput = document.getElementById('plateNumber');
const searchedPlateSpan = document.getElementById('searchedPlate');
const reviewsListDiv = document.getElementById('reviewsList');
const reviewPlateNumberInput = document.getElementById('reviewPlateNumber');
const ratingInput = document.getElementById('rating');
const reviewCommentInput = document.getElementById('reviewComment');

/**
 * Busca y muestra las reseñas del conductor.
 */
window.searchDriverReviews = async function() {
    if (!isAuthReady) {
        showModal("La autenticación no está lista. Por favor, espera un momento.");
        return;
    }
    const plate = plateNumberInput.value.trim().toUpperCase();
    if (!plate) {
        showModal("Por favor, ingresa un número de placa.");
        return;
    }

    searchedPlateSpan.innerText = plate;
    reviewsListDiv.innerHTML = '<p class="text-gray-600">Buscando calificaciones...</p>';

    try {
        const driverRatingsColRef = collection(db, `artifacts/${appId}/public/data/driverRatings`);
        const q = query(driverRatingsColRef, where("plateNumber", "==", plate));
        const querySnapshot = await getDocs(q);

        if (querySnapshot.empty) {
            reviewsListDiv.innerHTML = '<p class="text-gray-600">No hay calificaciones para esta placa aún.</p>';
            return;
        }

        let totalRating = 0;
        let reviewCount = 0;
        let reviewsHtml = '';

        querySnapshot.forEach(doc => {
            const data = doc.data();
            totalRating += data.rating;
            reviewCount++;
            reviewsHtml += `
                <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                    <p class="font-semibold text-gray-800">Calificación: ${'⭐'.repeat(data.rating)} (${data.rating}/5)</p>
                    <p class="text-gray-700 mt-1">${data.comment}</p>
                    <p class="text-xs text-gray-500 mt-2">Por: ${data.userId} el ${new Date(data.timestamp?.toDate()).toLocaleString()}</p>
                </div>
            `;
        });

        const averageRating = (totalRating / reviewCount).toFixed(1);
        reviewsListDiv.innerHTML = `
            <p class="text-lg font-bold text-gray-900 mb-3">Calificación Promedio: ${averageRating}/5 (${reviewCount} reseñas)</p>
            ${reviewsHtml}
        `;

    } catch (error) {
        console.error("Error al buscar calificaciones del conductor:", error);
        showModal(`Error al buscar calificaciones: ${error.message}`);
        reviewsListDiv.innerHTML = '<p class="text-red-600">Error al cargar calificaciones.</p>';
    }
};

/**
 * Envía una calificación de conductor a Firestore.
 */
window.submitDriverReview = async function() {
    if (!isAuthReady) {
        showModal("La autenticación no está lista. Por favor, espera un momento.");
        return;
    }
    const plate = reviewPlateNumberInput.value.trim().toUpperCase();
    const rating = parseInt(ratingInput.value);
    const comment = reviewCommentInput.value.trim();

    if (!plate || isNaN(rating) || rating < 1 || rating > 5 || !comment) {
        showModal("Por favor, completa todos los campos: placa, calificación (1-5) y comentario.");
        return;
    }

    try {
        const driverRatingsColRef = collection(db, `artifacts/${appId}/public/data/driverRatings`);
        await addDoc(driverRatingsColRef, {
            plateNumber: plate,
            rating: rating,
            comment: comment,
            userId: userId, // Usa el ID del usuario autenticado actual
            timestamp: serverTimestamp()
        });

        showModal("¡Calificación enviada con éxito!");
        reviewPlateNumberInput.value = '';
        ratingInput.value = '';
        reviewCommentInput.value = '';
        // Opcionalmente, actualiza la pantalla para la placa buscada si coincide
        if (plateNumberInput.value.trim().toUpperCase() === plate) {
            searchDriverReviews();
        }

    } catch (error) {
        console.error("Error al enviar la calificación:", error);
        showModal(`Error al enviar la calificación: ${error.message}`);
    }
};

// --- Lógica de Reportes Comunitarios (Firestore) ---
const reportTypeSelect = document.getElementById('reportType');
const reportDescriptionTextarea = document.getElementById('reportDescription');
const reportPhotoInput = document.getElementById('reportPhoto');
const communityReportsListDiv = document.getElementById('communityReportsList');

/**
 * Muestra los reportes comunitarios en la interfaz.
 * @param {Array<Object>} reports - Array de objetos de reporte.
 */
function displayCommunityReports(reports) {
    if (reports.length === 0) {
        communityReportsListDiv.innerHTML = '<p class="text-gray-600">No hay reportes comunitarios aún.</p>';
        return;
    }

    let reportsHtml = '';
    reports.forEach(report => {
        const timestamp = report.timestamp ? new Date(report.timestamp.toDate()).toLocaleString() : 'Fecha desconocida';
        reportsHtml += `
            <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <p class="font-semibold text-gray-800">Tipo: ${report.type}</p>
                <p class="text-gray-700 mt-1">${report.description}</p>
                <p class="text-xs text-gray-500 mt-2">
                    Por: ${report.userId} el ${timestamp}
                    ${report.latitude && report.longitude ? ` (Ubicación: ${report.latitude.toFixed(4)}, ${report.longitude.toFixed(4)})` : ''}
                </p>
                <div class="flex items-center mt-3">
                    <button class="bg-blue-100 text-blue-800 text-sm font-medium px-2.5 py-0.5 rounded-full hover:bg-blue-200 transition duration-150" onclick="showModal('Funcionalidad de "Me gusta" simulada.')">
                        <i class="fas fa-thumbs-up mr-1"></i> Me gusta
                    </button>
                    <span class="ml-2 text-gray-600">(${report.likes || 0})</span>
                </div>
            </div>
        `;
    });
    communityReportsListDiv.innerHTML = reportsHtml;
}

/**
 * Envía un reporte comunitario a Firestore.
 */
window.submitCommunityReport = async function() {
    if (!isAuthReady) {
        showModal("La autenticación no está lista. Por favor, espera un momento.");
        return;
    }
    const type = reportTypeSelect.value;
    const description = reportDescriptionTextarea.value.trim();
    // La carga de fotos/videos es compleja y requiere almacenamiento, por lo que se simula aquí.
    // const photoFile = reportPhotoInput.files[0];

    if (!type || !description) {
        showModal("Por favor, selecciona un tipo de incidente y escribe una descripción.");
        return;
    }

    let locationData = {};
    if (navigator.geolocation) {
        try {
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                });
            });
            locationData = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            };
        } catch (error) {
            console.warn("No se pudo obtener la ubicación para el reporte:", error);
            showModal("No se pudo obtener tu ubicación para el reporte. El reporte se enviará sin ubicación.");
        }
    } else {
        console.warn("Geolocalización no soportada para reportes.");
    }

    try {
        const reportsColRef = collection(db, `artifacts/${appId}/public/data/communityReports`);
        await addDoc(reportsColRef, {
            type: type,
            description: description,
            userId: userId,
            timestamp: serverTimestamp(),
            ...locationData,
            likes: 0 // Inicializa los "me gusta"
        });

        showModal("¡Reporte enviado con éxito! Gracias por tu contribución.");
        reportTypeSelect.value = '';
        reportDescriptionTextarea.value = '';
        reportPhotoInput.value = ''; // Limpia la entrada de archivo
    } catch (error) {
        console.error("Error al enviar el reporte comunitario:", error);
        showModal(`Error al enviar el reporte: ${error.message}`);
    }
};
